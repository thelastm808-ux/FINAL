# Parity Workbench (Gemini edition)
Windows cmd, from this folder (needs Node 18+; `winget install OpenJS.NodeJS.LTS`, then reopen cmd):

    copy api_keys.example.txt api_keys.txt
    notepad api_keys.txt          (paste keys, one per line, "1-KEY" style is fine)
    node check-keys.js            (shows which keys work and by which route)
    node server.js                (open http://127.0.0.1:3000)

Or double-click start.bat. Keys are re-read on every message, so you can add keys without restarting.
Optional: set GEMINI_MODEL=gemini-3.8-flash (default) | set BRAVE_API_KEY=... (image_search) | git clone https://github.com/anthropics/skills skills
Tests (no real keys needed): node test.js && node test-gemini.js
bash_tool uses Git Bash if installed at C:\Program Files\Git\bin\bash.exe, otherwise cmd.exe.
